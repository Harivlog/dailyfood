import React from 'react';

import './Navbar.css';

const Navbar = () => (
  <div>
    Navbar
  </div>
);

export default Navbar;
